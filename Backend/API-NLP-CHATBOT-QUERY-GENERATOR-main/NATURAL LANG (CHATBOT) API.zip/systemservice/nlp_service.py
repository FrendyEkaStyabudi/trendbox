# backend/services/nlp_service.py
import requests
import re
from config import Settings

# (Fungsi _parse_sql_and_reason dan _generate_sql_from_endpoint tetap sama persis seperti sebelumnya)
def _parse_sql_and_reason(model_output_text: str):
    # ... (Tidak ada perubahan di sini)
    sql_query = ""
    reasoning = "Tidak ada alasan spesifik yang ditemukan atau format output model tidak sesuai."
    cleaned_output = model_output_text.strip()
    
    structured_match = re.search(r"SQL Query:\s*(SELECT .*?;)\s*Reasoning:\s*(.*)", cleaned_output, re.IGNORECASE | re.DOTALL)
    if structured_match:
        sql_query = structured_match.group(1).strip()
        reasoning = structured_match.group(2).strip()
    else:
        sql_only_match = re.search(r"(SELECT .*?;)", cleaned_output, re.IGNORECASE | re.DOTALL)
        if sql_only_match:
            sql_query = sql_only_match.group(1).strip()
            potential_reasoning = cleaned_output[sql_only_match.end():].strip()
            if potential_reasoning:
                reasoning = re.sub(r"^\s*Reasoning:\s*", "", potential_reasoning, flags=re.IGNORECASE).strip() or "Query SQL ditemukan, tanpa teks alasan."
            else:
                reasoning = "Query SQL ditemukan, tanpa teks alasan."
        else:
            reasoning = f"Model tidak menghasilkan query SQL yang valid. Output: {cleaned_output[:300]}..."
            if not cleaned_output:
                reasoning = "Model menghasilkan output kosong."

    reasoning = re.sub(r"<end_of_turn>.*", "", reasoning, flags=re.IGNORECASE | re.DOTALL).strip()
    return sql_query, reasoning

def _generate_sql_from_endpoint(prompt: str, endpoint_url: str, api_key: str, model_name: str, provider_name: str):
    # ... (Tidak ada perubahan di sini)
    if not endpoint_url:
        return "", f"URL Endpoint untuk provider '{provider_name}' tidak diatur."

    system_prompt = """You are an intelligent AI specialized in generating SQL queries from natural language.
You will be given a database table schema and a user question.
Your task is to generate a syntactically correct SQL query to answer the question and provide a brief reasoning.
The table name is `emotion_tracking` and it has columns: `id` (INT), `emotion` (VARCHAR(20)), `timestamp` (DATETIME).
Possible emotion values are: 'happy', 'sad', 'angry', 'fear', 'surprised', 'neutral'.
Structure your response EXACTLY as follows, with NO other text before or after 'SQL Query:':
SQL Query:
SELECT ...;
Reasoning:
Your reasoning here."""

    headers = { "Content-Type": "application/json" }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    payload = {
        "model": model_name,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"User Question: \"{prompt}\""}
        ],
        "temperature": 0.3,
        "max_tokens": 400,
    }

    try:
        print(f"NLP Service ({provider_name}): Mengirim request ke {endpoint_url}")
        response = requests.post(endpoint_url, headers=headers, json=payload, timeout=60)
        response.raise_for_status()
        api_response_data = response.json()

        content = api_response_data.get('choices', [{}])[0].get('message', {}).get('content', '')
        if not content:
            return "", f"Format respons API '{provider_name}' tidak valid atau tidak ada konten."

        print(f"\n=== RAW API OUTPUT ({provider_name}) ===\n{content}\n========================\n")
        return _parse_sql_and_reason(content)
    except requests.exceptions.RequestException as e:
        return "", f"Gagal terhubung ke '{provider_name}' API di {endpoint_url}. Error: {e}"
    except Exception as e:
        return "", f"Error saat memproses respons API '{provider_name}': {e}"


def generate_sql_and_reason(prompt: str, config: Settings):
    """
    Fungsi utama yang menghasilkan SQL.
    Defaultnya Groq, dan akan memberikan error jika API key belum di-set.
    """
    print(f"NLP Service: Menghasilkan SQL dengan provider '{config.PROVIDER}'")
    
    if config.PROVIDER == 'groq':
        if not config.GROQ_API_KEY:
            error_msg = "Provider di-set ke 'groq' tapi API Key belum diatur. Silakan atur API Key melalui endpoint pengaturan."
            return "", error_msg
            
        groq_endpoint = "https://api.groq.com/openai/v1/chat/completions"
        return _generate_sql_from_endpoint(prompt, groq_endpoint, config.GROQ_API_KEY, config.GROQ_MODEL_NAME, "Groq")
    
    elif config.PROVIDER == 'local':
        if not config.LOCAL_ENDPOINT_URL:
            error_msg = "Provider di-set ke 'local' tapi URL Endpoint lokal belum diatur."
            return "", error_msg
        return _generate_sql_from_endpoint(prompt, config.LOCAL_ENDPOINT_URL, "", "local-model", "Lokal")
    
    else:
        error_msg = f"Provider tidak didukung: '{config.PROVIDER}'. Pilih 'groq' atau 'local'."
        return "", error_msg