# Di dalam file: backend/services/db_service.py

import mysql.connector
import pandas as pd
from config import settings

def execute_sql_query(sql_query: str):
    if not sql_query or not sql_query.strip():
        return {"data": None, "error": "Query SQL kosong diterima."}

    # --- PERBAIKAN DI SINI ---
    db_config = {
        'host': settings.DB_HOST,
        'user': settings.DB_USER,
        'password': settings.DB_PASSWORD,
        'database': settings.DB_NAME,
        'port': settings.DB_PORT, # <-- TAMBAHKAN BARIS INI
        'connect_timeout': 10
    }
    # -------------------------

    conn = None
    cursor = None
    try:
        print(f"DB Service: Mencoba koneksi ke DB {settings.DB_USER}@{settings.DB_HOST}:{settings.DB_PORT}") # Log port
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor(dictionary=True)
        print(f"DB Service: Mengeksekusi SQL: {sql_query}")
        cursor.execute(sql_query)
        
        if sql_query.strip().upper().startswith("SELECT"):
            results = cursor.fetchall()
            print(f"DB Service: Mengambil {len(results)} baris.")
            if results:
                # Konversi kolom datetime ke string agar aman untuk JSON
                df = pd.DataFrame(results)
                for col in df.select_dtypes(include=['datetime64[ns]', 'datetime', 'datetimetz']).columns:
                    df[col] = df[col].astype(str)
                return {"data": df.to_dict(orient='records'), "error": None}
            else:
                return {"data": [], "error": None, "info": "Tidak ada data yang ditemukan untuk query ini."}
        else:
            conn.commit()
            return {"data": [{"affected_rows": cursor.rowcount}], "error": None, "info": f"Query berhasil dieksekusi. Baris terpengaruh: {cursor.rowcount}"}

    except mysql.connector.Error as err:
        error_msg = f"MySQL Error: {err.errno} - {err.msg}"
        print(f"DB Service {error_msg}")
        return {"data": None, "error": error_msg}
    except Exception as e:
        print(f"DB Service General Error: {e}")
        return {"data": None, "error": f"Terjadi kesalahan pada layanan database: {str(e)}"}
    finally:
        if cursor:
            cursor.close()
        if conn and conn.is_connected():
            conn.close()